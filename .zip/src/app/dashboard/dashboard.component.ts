import { Component, OnInit } from '@angular/core';

export interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {


  selectedValue: string;

  foods: Food[] = [
    {value: 'steak-0', viewValue: 'London Branch'},
    {value: 'pizza-1', viewValue: 'Norway Branch'},
    {value: 'tacos-2', viewValue: 'Spain Branch'}
  ];
  
  constructor() {


   }

  ngOnInit() {

    this.selectedValue = "steak-0";
  }

}
